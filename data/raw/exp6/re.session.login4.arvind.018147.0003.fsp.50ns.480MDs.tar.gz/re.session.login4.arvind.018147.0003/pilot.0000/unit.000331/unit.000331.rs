cpu_index_using: physical
rank: 0: { host: 56; cpu: {4,5,6,7}; gpu: {1}}
