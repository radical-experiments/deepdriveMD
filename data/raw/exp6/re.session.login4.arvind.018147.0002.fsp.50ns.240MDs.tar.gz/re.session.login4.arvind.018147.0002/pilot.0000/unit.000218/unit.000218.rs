cpu_index_using: physical
rank: 0: { host: 37; cpu: {8,9,10,11}; gpu: {2}}
