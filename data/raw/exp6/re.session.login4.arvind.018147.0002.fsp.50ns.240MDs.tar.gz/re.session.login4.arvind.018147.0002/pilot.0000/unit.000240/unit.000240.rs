cpu_index_using: physical
rank: 0: { host: 1; cpu: {0}}
