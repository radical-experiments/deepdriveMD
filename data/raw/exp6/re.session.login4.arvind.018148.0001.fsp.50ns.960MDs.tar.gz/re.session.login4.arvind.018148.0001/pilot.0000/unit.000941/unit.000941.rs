cpu_index_using: physical
rank: 0: { host: 157; cpu: {20,21,22,23}; gpu: {5}}
