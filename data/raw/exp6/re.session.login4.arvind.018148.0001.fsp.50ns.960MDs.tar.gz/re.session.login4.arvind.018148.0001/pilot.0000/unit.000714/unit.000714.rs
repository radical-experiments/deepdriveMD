cpu_index_using: physical
rank: 0: { host: 120; cpu: {0,1,2,3}; gpu: {0}}
