#!/bin/sh

# some inspection for logging
hostname

# disable user site packages as those can conflict with our virtualenv
export PYTHONNOUSERSITE=True

# make sure we use the correct sandbox
cd /gpfs/alpine/scratch/arvind/bip179/radical.pilot.sandbox/re.session.login4.arvind.018148.0001/pilot.0000

# apply some env settings as stored after running pre_bootstrap_0 commands
export PATH="/sw/sources/lsf-tools/2.0/summit/bin:/gpfs/alpine/world-shared/stf010/naughton/olcf/summit/prrte/install/gcc-6.4.0/prrte_install/bin:/autofs/nccs-svm1_sw/summit/.swci/1-compute/opt/spack/20180914/linux-rhel7-ppc64le/gcc-6.4.0/zeromq-4.2.5-hyfaxk5dcmezj6rhlmz6tcqg2pat53ee/bin:/autofs/nccs-svm1_sw/summit/.swci/0-core/opt/spack/20180914/linux-rhel7-ppc64le/gcc-4.8.5/py-setuptools-40.2.0-qqpdu4ekvahwefforf22v6k4ifepvirw/bin:/autofs/nccs-svm1_sw/summit/.swci/0-core/opt/spack/20180914/linux-rhel7-ppc64le/gcc-4.8.5/py-pip-10.0.1-2gr5x7tsnuxwissqhzapdbmlpheove3i/bin:/autofs/nccs-svm1_sw/summit/.swci/0-core/opt/spack/20180914/linux-rhel7-ppc64le/gcc-4.8.5/py-virtualenv-16.0.0-phcok3x4eyd36qfh5ptv66isyol4ui4b/bin:/autofs/nccs-svm1_sw/summit/.swci/1-compute/opt/spack/20180914/linux-rhel7-ppc64le/gcc-6.4.0/python-2.7.15-cjt4lebz4gaoqaiqw2q5frxpro5fatay/bin:/sw/summit/gcc/6.4.0/bin:/autofs/nccs-svm1_sw/summit/.swci/0-core/opt/spack/20180914/linux-rhel7-ppc64le/gcc-4.8.5/tmux-2.2-z2cgytxdo3rzw643uj2fiwp7iwqbbbwp/bin:/sw/summit/cuda/9.1.85/bin:/usr/bin:/usr/sbin:/opt/ibm/csm/bin:/opt/ibm/spectrumcomputing/lsf/10.1/linux3.10-glibc2.17-ppc64le-csm/bin:/ccs/home/hm0/.conda/envs/entk/bin:/autofs/nccs-svm1_sw/summit/.swci/1-compute/opt/spack/20180914/linux-rhel7-ppc64le/gcc-4.8.5/darshan-runtime-3.1.7-csygoqyym3m3ysoaperhxlhoiluvpa2u/bin:/sw/sources/hpss/bin:/opt/ibm/spectrumcomputing/lsf/10.1/linux3.10-glibc2.17-ppc64le-csm/etc:/usr/local/bin:/usr/local/sbin:/opt/ibm/flightlog/bin:/opt/ibutils/bin:/opt/ibm/spectrum_mpi/jsm_pmix/bin:/opt/puppetlabs/bin:/usr/lpp/mmfs/bin"
export LD_LIBRARY_PATH="/gpfs/alpine/world-shared/stf010/naughton/olcf/summit/prrte/install/gcc-6.4.0/prrte_install/lib:/autofs/nccs-svm1_sw/summit/.swci/1-compute/opt/spack/20180914/linux-rhel7-ppc64le/gcc-6.4.0/zeromq-4.2.5-hyfaxk5dcmezj6rhlmz6tcqg2pat53ee/lib:/autofs/nccs-svm1_sw/summit/.swci/0-core/opt/spack/20180914/linux-rhel7-ppc64le/gcc-4.8.5/py-setuptools-40.2.0-qqpdu4ekvahwefforf22v6k4ifepvirw/lib:/autofs/nccs-svm1_sw/summit/.swci/0-core/opt/spack/20180914/linux-rhel7-ppc64le/gcc-4.8.5/py-pip-10.0.1-2gr5x7tsnuxwissqhzapdbmlpheove3i/lib:/autofs/nccs-svm1_sw/summit/.swci/0-core/opt/spack/20180914/linux-rhel7-ppc64le/gcc-4.8.5/py-virtualenv-16.0.0-phcok3x4eyd36qfh5ptv66isyol4ui4b/lib:/autofs/nccs-svm1_sw/summit/.swci/1-compute/opt/spack/20180914/linux-rhel7-ppc64le/gcc-6.4.0/python-2.7.15-cjt4lebz4gaoqaiqw2q5frxpro5fatay/lib:/sw/summit/gcc/6.4.0/lib64:/sw/summit/cuda/9.1.85/lib64:/opt/ibm/spectrumcomputing/lsf/10.1/linux3.10-glibc2.17-ppc64le-csm/lib:/autofs/nccs-svm1_sw/summit/.swci/1-compute/opt/spack/20180914/linux-rhel7-ppc64le/gcc-4.8.5/darshan-runtime-3.1.7-csygoqyym3m3ysoaperhxlhoiluvpa2u/lib:/opt/ibm/spectrum_mpi/jsm_pmix/lib"

# activate virtenv
if test "default" = "anaconda"
then
    source activate /gpfs/alpine/bip179/scratch/arvind/radical.pilot.sandbox/ve.ornl.summit.0.70.0/
else
    . /gpfs/alpine/bip179/scratch/arvind/radical.pilot.sandbox/ve.ornl.summit.0.70.0/bin/activate
fi

# make sure rp_install is used
export PYTHONPATH=/gpfs/alpine/scratch/arvind/bip179/radical.pilot.sandbox/re.session.login4.arvind.018148.0001/pilot.0000/rp_install/lib/python2.7/site-packages::/autofs/nccs-svm1_sw/summit/.swci/0-core/opt/spack/20180914/linux-rhel7-ppc64le/gcc-4.8.5/py-setuptools-40.2.0-qqpdu4ekvahwefforf22v6k4ifepvirw/lib/python2.7/site-packages:/autofs/nccs-svm1_sw/summit/.swci/0-core/opt/spack/20180914/linux-rhel7-ppc64le/gcc-4.8.5/py-pip-10.0.1-2gr5x7tsnuxwissqhzapdbmlpheove3i/lib/python2.7/site-packages:/autofs/nccs-svm1_sw/summit/.swci/0-core/opt/spack/20180914/linux-rhel7-ppc64le/gcc-4.8.5/py-virtualenv-16.0.0-phcok3x4eyd36qfh5ptv66isyol4ui4b/lib/python2.7/site-packages

# run agent in debug mode
# FIXME: make option again?
export RADICAL_VERBOSE=DEBUG
export RADICAL_UTIL_VERBOSE=DEBUG
export RADICAL_PILOT_VERBOSE=DEBUG

# the agent will *always* use the dburl from the config file, not from the env
# FIXME: can we better define preference in the session ctor?
unset RADICAL_PILOT_DBURL

# avoid ntphost lookups on compute nodes
export RADICAL_PILOT_NTPHOST=46.101.140.169

# pass environment variables down so that module load becomes effective at
# the other side too (e.g. sub-agents).

module unload xl
module unload xalt
module unload spectrum-mpi
module load gcc/6.4.0
module load python/2.7.15
module load py-virtualenv/16.0.0-py2
module load py-pip/10.0.1-py2
module load py-setuptools/40.2.0-py2
module load zeromq/4.2.5
module use /gpfs/alpine/stf010/world-shared/naughton/olcf/summit/modulefiles
module load prrte/master
export PRRTE_PREFIX=/gpfs/alpine/world-shared/stf010/naughton/olcf/summit/prrte/install/gcc-6.4.0/prrte_install

# start agent, forward arguments
# NOTE: exec only makes sense in the last line of the script
exec /gpfs/alpine/bip179/scratch/arvind/radical.pilot.sandbox/ve.ornl.summit.0.70.0/bin/python /gpfs/alpine/scratch/arvind/bip179/radical.pilot.sandbox/re.session.login4.arvind.018148.0001/pilot.0000/rp_install/bin/radical-pilot-agent "$1" 1>"$1.out" 2>"$1.err"

