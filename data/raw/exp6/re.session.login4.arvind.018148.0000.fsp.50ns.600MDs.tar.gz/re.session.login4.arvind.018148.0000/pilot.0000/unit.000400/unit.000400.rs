cpu_index_using: physical
rank: 0: { host: 67; cpu: {16,17,18,19}; gpu: {4}}
