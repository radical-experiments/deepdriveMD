cpu_index_using: physical
rank: 0: { host: 71; cpu: {12,13,14,15}; gpu: {3}}
